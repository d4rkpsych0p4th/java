
package juegorol;

public class JuegoRol {


    public static void main(String[] args) {
        Logica.Iniciar();
    }
    
}



